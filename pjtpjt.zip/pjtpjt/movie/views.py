from django.shortcuts import render
from django.views.generic import ListView
from .models import Movie

# Create your views here.


def index(request):
    movies = Movie.objects.all().order_by('-pk')


    return render(request,'movie/index.html',
    {
        'movies':movies
    })

def community(request,pk):
    movies = Movie.objects.get(pk=pk)
    return render(request,'movie/community.html',
    {
        'movies': movies,
    })