from django.shortcuts import render

# Create your views here.
def about_me(request):
    return render(
        request,
        'community/about_me.html'
    )


def landing(request):
    return render(
        request,
        'community/landing.html'
    )