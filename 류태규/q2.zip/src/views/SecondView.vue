<template>
  <div class="second">
    <h1>두 번째 페이지입니다</h1>
  </div>
</template>
