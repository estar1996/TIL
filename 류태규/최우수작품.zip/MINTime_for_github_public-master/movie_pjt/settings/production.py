from .base import *

DEBUG = False

ALLOWED_HOSTS = [
    '.compute.amazonaws.com',
    '13.124.169.106',
]