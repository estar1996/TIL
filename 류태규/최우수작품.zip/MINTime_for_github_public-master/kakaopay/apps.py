from django.apps import AppConfig


class KakaopayConfig(AppConfig):
    name = 'kakaopay'
