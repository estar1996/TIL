from django.apps import AppConfig


class CommunityConfig(AppConfig):
    name = 'community'
