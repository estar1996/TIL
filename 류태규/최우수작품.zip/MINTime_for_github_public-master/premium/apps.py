from django.apps import AppConfig


class PremiumConfig(AppConfig):
    name = 'premium'
