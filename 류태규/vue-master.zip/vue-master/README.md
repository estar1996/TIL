# 8기 Vue.js 라이브 코드

| Day  | Subject         |
| ---- | --------------- |
| 01   | Vue 기초        |
| 03   | Vue CLI         |
| 05   | Vuex            |
| 07   | Vue Router      |
| 09   | Vue with Django |

